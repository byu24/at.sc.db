---
name: Question
about: Ask a question.
title: ''
labels: 'type: question'
assignees: ''

---

## Prework

- [ ] Read and abide by `drake`'s [code of conduct](https://github.com/ropensci/drake/blob/master/CODE_OF_CONDUCT.md).
- [ ] Search for duplicates among the [existing issues](https://github.com/ropensci/drake/issues), both open and closed.
- [ ] Consider instead posting to [Stack Overflow](https://stackoverflow.com) under the [`drake-r-package` tag](https://stackoverflow.com/tags/drake-r-package).

## Question

What would you like to know?
